import React, { useState, useEffect } from 'react';
import { collection, getDocs, updateDoc, doc, query, orderBy } from 'firebase/firestore';
import { db } from '../firebase';
import { MessageSquare, CheckCircle, Clock, User } from 'lucide-react';

export default function SupportTickets() {
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTickets = async () => {
      try {
        const q = query(collection(db, 'support_tickets'), orderBy('createdAt', 'desc'));
        const snap = await getDocs(q);
        setTickets(snap.docs.map(d => ({ id: d.id, ...d.data() })));
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    fetchTickets();
  }, []);

  const handleResolve = async (ticket) => {
    const status = ticket.status === 'resolved' ? 'open' : 'resolved';
    await updateDoc(doc(db, 'support_tickets', ticket.id), { status });
    setTickets(tickets.map(t => t.id === ticket.id ? { ...t, status } : t));
  };

  if (loading) return <div className="p-8 text-center text-gray-500">Loading Tickets...</div>;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold mb-2 text-white">Support Inbox</h2>
        <p className="text-gray-400">Respond to driver issues and feedback.</p>
      </div>

      <div className="grid gap-4">
        {tickets.length === 0 ? (
          <div className="bg-card p-12 text-center rounded-2xl border border-white/5 border-dashed">
            <MessageSquare className="mx-auto text-gray-600 mb-4" size={48} />
            <p className="text-gray-500">No support tickets found.</p>
          </div>
        ) : (
          tickets.map((ticket) => (
            <div 
              key={ticket.id} 
              className={`bg-card p-6 rounded-2xl border transition-all ${
                ticket.status === 'resolved' ? 'border-white/5 opacity-60' : 'border-primary/20 shadow-lg shadow-primary/5'
              }`}
            >
              <div className="flex justify-between items-start">
                <div className="flex gap-4 text-white">
                  <div className="w-12 h-12 bg-white/5 rounded-full flex items-center justify-center text-primary">
                    <User size={24} />
                  </div>
                  <div>
                    <div className="flex items-center gap-3 mb-1">
                      <h4 className="font-bold text-lg">{ticket.userPhone || 'Unknown User'}</h4>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                        ticket.status === 'resolved' ? 'bg-green-500/10 text-green-500' : 'bg-primary/10 text-primary'
                      }`}>
                        {ticket.status}
                      </span>
                    </div>
                    <p className="text-gray-300 mb-3">{ticket.message}</p>
                    <div className="flex items-center gap-4 text-xs text-gray-500">
                      <span className="flex items-center gap-1">
                        <Clock size={12} /> {ticket.createdAt?.toDate().toLocaleString()}
                      </span>
                      <span className="flex items-center gap-1 font-mono">
                        UID: {ticket.userId?.substring(0, 8)}...
                      </span>
                    </div>
                  </div>
                </div>
                <button 
                  onClick={() => handleResolve(ticket)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all ${
                    ticket.status === 'resolved' 
                    ? 'bg-white/5 text-gray-400 hover:bg-white/10' 
                    : 'bg-primary text-black hover:scale-105 active:scale-95'
                  }`}
                >
                  <CheckCircle size={16} />
                  {ticket.status === 'resolved' ? 'RE-OPEN' : 'MARK RESOLVED'}
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
